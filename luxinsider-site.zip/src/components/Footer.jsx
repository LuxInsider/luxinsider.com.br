import React from 'react';

function Footer() {
  return (
    <footer className="py-6 text-center text-sm text-gray-500 bg-white border-t">
      © {new Date().getFullYear()} Lux Insider. Todos os direitos reservados.
    </footer>
  );
}

export default Footer;
