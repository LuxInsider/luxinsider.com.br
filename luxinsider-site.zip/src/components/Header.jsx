import React from 'react';

function Header() {
  return (
    <header className="fixed top-0 w-full bg-white shadow z-50">
      <div className="max-w-6xl mx-auto px-4 py-4 flex justify-between items-center">
        <img src="/logo.png" alt="Lux Insider Logo" className="h-10" />
        <nav className="space-x-6 text-sm">
          <a href="#sobre" className="hover:text-blue-600">Sobre</a>
          <a href="#servicos" className="hover:text-blue-600">Serviços</a>
          <a href="#contato" className="hover:text-blue-600">Contato</a>
        </nav>
      </div>
    </header>
  );
}

export default Header;
