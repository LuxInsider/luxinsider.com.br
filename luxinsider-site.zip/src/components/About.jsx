import React from 'react';

function About() {
  return (
    <section id="sobre" className="py-20 px-4 bg-gray-50 text-center">
      <h2 className="text-3xl font-bold mb-6">Quem Somos</h2>
      <p className="max-w-2xl mx-auto text-gray-600">
        A Lux Insider é uma assistência técnica especializada que oferece experiência premium em conserto de celulares e PCs, com atendimento personalizado e rápido para fazer você se sentir parte da realeza.
      </p>
    </section>
  );
}

export default About;
