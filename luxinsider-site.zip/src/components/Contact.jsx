import React from 'react';

function Contact() {
  return (
    <section id="contato" className="py-20 px-4 bg-gray-50 text-center">
      <h2 className="text-3xl font-bold mb-8">Entre em Contato</h2>
      <div className="space-y-4 text-gray-700">
        <p>WhatsApp: <a href="https://wa.me/5511974272013" className="text-blue-600">+55 (11) 97427-2013</a></p>
        <p>Email: <a href="mailto:contato@luxinsider.com.br" className="text-blue-600">contato@luxinsider.com.br</a></p>
        <p>Instagram: <a href="https://instagram.com/luxinsider.oficial" className="text-blue-600">@luxinsider.oficial</a></p>
      </div>
    </section>
  );
}

export default Contact;
