import React from 'react';

function Services() {
  return (
    <section id="servicos" className="py-20 px-4 bg-white text-center">
      <h2 className="text-3xl font-bold mb-10">Nossos Serviços</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto">
        <div className="p-6 border rounded shadow-sm">
          <h3 className="font-semibold text-xl mb-2">Assistência Técnica</h3>
          <p>Manutenção e reparo de celulares e computadores.</p>
        </div>
        <div className="p-6 border rounded shadow-sm">
          <h3 className="font-semibold text-xl mb-2">Upgrades</h3>
          <p>Melhoria de performance e atualização de hardware.</p>
        </div>
        <div className="p-6 border rounded shadow-sm">
          <h3 className="font-semibold text-xl mb-2">Diagnóstico</h3>
          <p>Análise precisa e rápida para identificar qualquer problema.</p>
        </div>
      </div>
    </section>
  );
}

export default Services;
