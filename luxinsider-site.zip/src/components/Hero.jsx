import React from 'react';

function Hero() {
  return (
    <section className="h-screen flex items-center justify-center bg-gradient-to-br from-blue-100 to-white text-center px-4 pt-20">
      <div>
        <h1 className="text-4xl md:text-6xl font-bold mb-4">Tecnologia a nível da realeza</h1>
        <p className="text-lg text-gray-700 max-w-xl mx-auto">Atendimento premium em assistência técnica para celulares e computadores.</p>
      </div>
    </section>
  );
}

export default Hero;
